import { useFetchDocument } from '../../hooks/useFetchDocument';
import { useParams } from 'react-router-dom';
import styles from './PostDetail.module.css';

export const PostDetail = () => {
  const { id } = useParams();
  const { document: post, loading, error } = useFetchDocument('posts', id);

  // 1. Tratar estado de carregamento
  if (loading) {
    return <div className={styles.loading}>Carregando post...</div>;
  }
  if (!id) return <div className={styles.error}>ID do post não fornecido</div>;
  // 2. Tratar erros
  if (error) {
    return <div className={styles.error}>Erro ao carregar post: {error}</div>;
  }

  // 3. Verificar se o post existe
  if (!post) {
    return <div className={styles.notFound}>Post não encontrado</div>;
  }

  // 4. Só renderiza o post se ele existir
  return (
    <div className={styles.postDetail}>
      <h1>{post.title}</h1>
      
      {/* 5. Renderização condicional da imagem */}
      {post.image && (
        <img 
          src={post.image} 
          alt={post.title}
          className={styles.postImage}
          onError={(e) => {
            e.target.src = '/placeholder-image.jpg';
          }}
        />
      )}
      
      <p className={styles.postBody}>{post.body}</p>
      
      {/* 6. Renderização segura das tags */}
      <div className={styles.tags}>
        {post.tags?.map((tag, index) => (
          <span key={index} className={styles.tag}>#{tag}</span>
        ))}
      </div>
    </div>
  );
};